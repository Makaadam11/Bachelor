 ========================================================================
Autor: Adam Mąka,                               Krakow, 14.03.2022
========================================================================

 Zawartosc:
============

Katalog programy zawiera jeden program w C++:
--------------------------------------------------------------------

I.  Program wypisujacy wszystkie funkcjonalności zadane w ćwiczeniu. 
    Program zawiera implementacje dla metod dla int-ów i string-ów;
    Program sklada sie z jednego pliku .cpp:
    1) Main.cpp  - program glowny zawierający implementację wszystkich
			funkcji.


Note:
    Plik Makefile jest w podstawowej wersji, ponieważ używam windows 
    i korzystam z WSL w Visual Studio 2019 oraz programu Chocolatey,
    który generuje plik .exe do uruchomienia programu.
------------------------------------------------------------------------
========================================================================



